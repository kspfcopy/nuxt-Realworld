import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _23afc1aa = () => interopDefault(import('..\\pages\\layouts' /* webpackChunkName: "" */))
const _a5f64d44 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _1862ca6c = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _13b9e0ca = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _167b6dbc = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _7978e22c = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _0af7b7d2 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _23afc1aa,
    children: [{
      path: "",
      component: _a5f64d44,
      name: "home"
    }, {
      path: "/login",
      component: _1862ca6c,
      name: "login"
    }, {
      path: "/register",
      component: _1862ca6c,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _13b9e0ca,
      name: "profile"
    }, {
      path: "/settings",
      component: _167b6dbc,
      name: "settings"
    }, {
      path: "/editor",
      component: _7978e22c,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _0af7b7d2,
      name: "article"
    }]
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
