const middleware = {}

middleware['isLogin'] = require('..\\middleware\\isLogin.js')
middleware['isLogin'] = middleware['isLogin'].default || middleware['isLogin']

middleware['notLogin'] = require('..\\middleware\\notLogin.js')
middleware['notLogin'] = middleware['notLogin'].default || middleware['notLogin']

export default middleware
